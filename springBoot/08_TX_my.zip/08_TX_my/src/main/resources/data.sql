-- ignore : 비어있다면
insert ignore into tbl_a values(1,111);
insert ignore into tbl_a values(2,222);
insert ignore into tbl_a values(3,333);
