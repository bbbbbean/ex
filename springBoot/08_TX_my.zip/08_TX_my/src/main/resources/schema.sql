-- test 용도로 자주 사용
create table if not exists tbl_a(id int primary key, pw int not null); -- 존재하지 않는다면